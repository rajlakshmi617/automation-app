import { Component} from '@angular/core';

@Component({
  selector: 'app-fieldvalidation',
  templateUrl: './fieldvalidation.component.html',
  styleUrls: ['./fieldvalidation.component.css'],
  
})
export class FieldvalidationComponent {


  ngOnInit() {
    
  }
}
